export class Review{
    author!:string;
    email!:string;
    rating!:string;
    description!:string;
}