//Some class containing some functionality
export class Sample{
    //to call this method, you will have to create 
    //the object of this class
    getMessage():string{
        return "Hello from Sample"
    }
}